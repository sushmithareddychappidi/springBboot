package org.jsp.Autowiring;

public interface Account {

}
