package org.jsp.Autowiring;

public interface Address 
{

}
